#!/usr/bin/env python3
"""Original lightweight Pygame ambient visual: aurora + starfield; click/Esc to close."""
import math
import random
import sys
import pygame

W, H = 960, 544
random.seed(24)


def main():
    pygame.init()
    screen = pygame.display.set_mode((W, H))
    pygame.display.set_caption('VITA AURORA | software graphics')
    clock = pygame.time.Clock()
    stars = [(random.randint(0, W), random.randint(0, H), random.uniform(.2, 1.2)) for _ in range(90)]
    t = 0.0
    while True:
        dt = clock.tick(24) / 1000
        t += dt
        for event in pygame.event.get():
            if event.type == pygame.QUIT or event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE or event.type == pygame.MOUSEBUTTONDOWN:
                pygame.quit()
                return
        screen.fill((4, 9, 25))
        pygame.draw.circle(screen, (17, 35, 68), (700, 153), 108)
        pygame.draw.circle(screen, (43, 57, 91), (700, 153), 83, 2)
        for x, y, f in stars:
            v = max(1, int((1 + math.sin(t * f + x / 30)) * 1.3))
            pygame.draw.circle(screen, (75 + int(65 * f), 125 + int(40 * f), 170 + int(44 * f)), (x, y), v)
        for layer in range(32):
            x0 = int((layer / 32) * W)
            phase = t * .43 + layer * .13
            h = int(240 + 94 * math.sin(phase) + 23 * math.sin(t * .17 + layer * .8))
            c = (11 + layer // 3, 66 + int(45 * (1 + math.sin(phase)) / 2), 85 + int(58 * (1 + math.sin(phase + 1)) / 2))
            pygame.draw.line(screen, c, (x0, h), (x0, H-45), 30)
        for j in range(12):
            y = int(H - 68 - j * 9)
            brightness = int(23 * (1 + math.sin(t + j * 0.5)) / 2)
            pygame.draw.line(screen, (15, 30 + brightness, 65 + brightness), (0, y), (W, y), 1)
        title = pygame.font.Font(None, 52).render('VITA / AURORA', True, (128, 234, 250))
        screen.blit(title, (38, 32))
        sub = pygame.font.Font(None, 25).render('ORIGINAL AMBIENT VISUAL   •   ESC / TOUCH TO CLOSE', True, (135, 166, 203))
        screen.blit(sub, (40, 88))
        pygame.display.flip()


if __name__ == '__main__':
    main()
