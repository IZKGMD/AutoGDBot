#!/usr/bin/env python3
"""NEON DRIFT: original 2D arcade written with Pygame for LinuxOnVita."""
import math
import random
import sys

import pygame

W, H = 960, 544
FPS = 30
CYAN = (74, 235, 254)
PINK = (248, 70, 145)
NIGHT = (6, 9, 23)


def clamp(value, lo, hi):
    return max(lo, min(hi, value))


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption('NEON DRIFT | LinuxOnVita')
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont('DejaVu Sans', 24, bold=True)
        self.big = pygame.font.SysFont('DejaVu Sans', 66, bold=True)
        self.small = pygame.font.SysFont('DejaVu Sans', 18)
        self.stars = [[random.randrange(W), random.randrange(H - 90), random.uniform(0.3, 1.3)] for _ in range(65)]
        self.buildings = [(x, random.randrange(28, 135), random.randrange(25, 65)) for x in range(0, W + 40, 44)]
        self.restart()

    def restart(self):
        self.ship_x = W * 0.5
        self.ship_y = H - 90
        self.health = 3
        self.score = 0
        self.passed = 0
        self.speed = 190
        self.obstacles = []
        self.particles = []
        self.spawn = 0.4
        self.shield = 0
        self.timer = 0
        self.over = False
        self.paused = False

    def burst(self, x, y, color):
        for _ in range(12):
            angle = random.random() * 6.28
            velocity = random.uniform(50, 210)
            self.particles.append([x, y, math.cos(angle)*velocity, math.sin(angle)*velocity, 0.6, color])

    def update(self, dt):
        if self.over or self.paused:
            return
        self.timer += dt
        keys = pygame.key.get_pressed()
        direction = int(keys[pygame.K_RIGHT] or keys[pygame.K_d]) - int(keys[pygame.K_LEFT] or keys[pygame.K_a])
        self.ship_x = clamp(self.ship_x + direction * dt * 370, 35, W-35)
        self.shield = max(0, self.shield - dt)
        self.speed = 190 + min(230, self.score / 12)
        self.score += dt * 18
        self.spawn -= dt
        if self.spawn < 0:
            r = random.randint(16, 33)
            self.obstacles.append([random.randint(35, W-35), -40, r, random.choice([0, 1])])
            self.spawn = max(0.28, 0.87 - self.score / 450)
        for obstacle in self.obstacles[:]:
            obstacle[1] += self.speed * dt
            if obstacle[1] > H + 40:
                self.obstacles.remove(obstacle)
                self.passed += 1
                continue
            dx = self.ship_x - obstacle[0]
            dy = self.ship_y - obstacle[1]
            if dx*dx + dy*dy < (obstacle[2] + 18)**2 and self.shield <= 0:
                self.health -= 1
                self.shield = 1.4
                self.burst(obstacle[0], obstacle[1], PINK)
                self.obstacles.remove(obstacle)
                if self.health <= 0:
                    self.over = True
        for p in self.particles[:]:
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[4] -= dt
            if p[4] < 0:
                self.particles.remove(p)

    def glow_text(self, value, font, color, x, y, center=False):
        surface = font.render(value, True, color)
        rect = surface.get_rect()
        rect.center = (x, y) if center else rect.center
        if not center:
            rect.topleft = (x, y)
        self.screen.blit(surface, rect)

    def draw(self):
        screen = self.screen
        screen.fill(NIGHT)
        pygame.draw.rect(screen, (10, 19, 44), (0, 145, W, H-145))
        pygame.draw.circle(screen, (30, 28, 74), (760, 145), 90)
        pygame.draw.circle(screen, (83, 45, 124), (760, 145), 51)
        for x, y, factor in self.stars:
            ty = int((y + self.timer * 6 * factor) % (H-165))
            pygame.draw.circle(screen, (52, 80, 118), (x, ty), 1)
        for x, height, width in self.buildings:
            pygame.draw.rect(screen, (13, 27, 55), (x, 245-height, width, height))
            for yy in range(252-height+11, 245, 16):
                pygame.draw.rect(screen, (28, 75, 112), (x+7, yy, 4, 5))
                pygame.draw.rect(screen, (33, 51, 110), (x+24, yy, 4, 5))
        horizon = 253
        pygame.draw.line(screen, (49, 222, 245), (0, horizon), (W, horizon), 2)
        pygame.draw.rect(screen, (8, 14, 29), (0, horizon+2, W, H-horizon))
        for i in range(12):
            z = ((i + self.timer * self.speed / 165) % 12) / 12
            y = int(horizon + z*z*(H-horizon))
            color = (12+int(z*24), 39+int(z*80), 63+int(z*100))
            pygame.draw.line(screen, color, (0, y), (W, y), 1)
        for x in (50, 140, 280, 480, 680, 820, 910):
            pygame.draw.line(screen, (20, 63, 95), (W//2, horizon), (x, H), 1)
        for x, y, radius, kind in self.obstacles:
            c = PINK if kind == 0 else (253, 147, 71)
            pygame.draw.circle(screen, (74, 21, 52), (int(x), int(y)), radius+7, 2)
            pygame.draw.circle(screen, c, (int(x), int(y)), radius, 3)
            pygame.draw.line(screen, c, (int(x)-radius//2, int(y)), (int(x)+radius//2, int(y)), 2)
        if self.shield <= 0 or int(self.timer * 12) % 2 == 0:
            x = int(self.ship_x)
            y = int(self.ship_y)
            hull = [(x, y-28), (x+24, y+20), (x+4, y+13), (x-4, y+13), (x-24, y+20)]
            pygame.draw.polygon(screen, (12, 64, 90), hull)
            pygame.draw.polygon(screen, CYAN, hull, 3)
            pygame.draw.line(screen, (241, 248, 255), (x, y-20), (x, y+10), 2)
            pygame.draw.polygon(screen, PINK, [(x-10, y+20), (x, y+29+random.randint(0, 10)), (x+10, y+20)])
        for x, y, vx, vy, ttl, color in self.particles:
            pygame.draw.circle(screen, color, (int(x), int(y)), max(1, int(ttl*6)))
        pygame.draw.rect(screen, (7, 14, 30), (18, 15, 345, 78), border_radius=12)
        pygame.draw.rect(screen, (54, 83, 111), (18, 15, 345, 78), 2, border_radius=12)
        self.glow_text('NEON DRIFT', self.font, CYAN, 30, 23)
        self.glow_text('SCORE %05d   HULL %s' % (int(self.score), '●'*self.health), self.small, (210, 224, 255), 30, 60)
        self.glow_text('← →  /  A D  •  TOUCH  •  P pause  •  R restart', self.small, (152, 169, 195), 27, H-33)
        if self.paused or self.over:
            overlay = pygame.Surface((W, H), pygame.SRCALPHA)
            overlay.fill((6, 9, 23, 186))
            screen.blit(overlay, (0, 0))
            self.glow_text('GAME OVER' if self.over else 'PAUSED', self.big, PINK if self.over else CYAN, W//2, H//2-40, True)
            self.glow_text('Press R or tap to restart' if self.over else 'Press P to resume', self.font,
                           (225, 230, 249), W//2, H//2+34, True)
        pygame.display.flip()

    def run(self):
        while True:
            dt = min(0.05, self.clock.tick(FPS) / 1000)
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    pygame.quit()
                    return
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_ESCAPE:
                        pygame.quit()
                        return
                    if e.key == pygame.K_r:
                        self.restart()
                    if e.key == pygame.K_p and not self.over:
                        self.paused = not self.paused
                if e.type == pygame.MOUSEBUTTONDOWN and self.over:
                    self.restart()
            pressed = pygame.mouse.get_pressed()[0]
            if pressed and not self.over and not self.paused:
                px = pygame.mouse.get_pos()[0]
                self.ship_x = clamp(self.ship_x + clamp(px-self.ship_x, -18, 18), 35, W-35)
            self.update(dt)
            self.draw()


if __name__ == '__main__':
    try:
        Game().run()
    except Exception as exc:
        print('NEON DRIFT ERROR:', repr(exc), file=sys.stderr)
        raise
