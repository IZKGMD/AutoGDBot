#!/usr/bin/env python3
"""ORBIT DEFENDER: original X11/Tk Canvas arcade for low-power LinuxOnVita."""
import math
import random
import tkinter as tk

W, H = 900, 500
NIGHT = '#080f20'
CYAN = '#59e7f7'
PINK = '#ff599c'


class Game:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title('ORBIT DEFENDER | Tk Canvas | LinuxOnVita')
        self.root.geometry('%dx%d+20+20' % (W, H))
        self.root.resizable(False, False)
        self.canvas = tk.Canvas(self.root, width=W, height=H, bg=NIGHT,
                                highlightthickness=0, bd=0)
        self.canvas.pack()
        self.keys = set()
        self.root.bind('<KeyPress>', self.press)
        self.root.bind('<KeyRelease>', self.release)
        self.canvas.bind('<Button-1>', self.touch)
        self.canvas.focus_set()
        random.seed()
        self.stars = [(random.randrange(W), random.randrange(H), random.randrange(1, 3))
                      for _ in range(65)]
        self.reset()
        self.frame()
        self.root.mainloop()

    def reset(self):
        self.player = W // 2
        self.shots = []
        self.meteors = []
        self.sparkles = []
        self.health = 5
        self.score = 0
        self.tick = 0
        self.cooldown = 0
        self.dead = False
        self.paused = False

    def press(self, event):
        if event.keysym == 'Escape':
            self.root.destroy()
            return
        self.keys.add(event.keysym.lower())
        if event.keysym.lower() == 'r':
            self.reset()
        if event.keysym.lower() == 'p':
            self.paused = not self.paused

    def release(self, event):
        self.keys.discard(event.keysym.lower())

    def touch(self, event):
        if self.dead:
            self.reset()
            return
        self.player = max(35, min(W - 35, event.x))
        self.fire()

    def fire(self):
        if self.cooldown <= 0 and not self.dead:
            self.shots.append([self.player, H - 82])
            self.cooldown = 7

    def update(self):
        if self.dead or self.paused:
            return
        self.tick += 1
        self.cooldown -= 1
        if 'left' in self.keys or 'a' in self.keys:
            self.player -= 13
        if 'right' in self.keys or 'd' in self.keys:
            self.player += 13
        self.player = max(30, min(W - 30, self.player))
        if 'space' in self.keys or 'up' in self.keys:
            self.fire()
        difficulty = min(12, self.score // 35)
        if self.tick % max(10, 29 - difficulty) == 0:
            self.meteors.append([random.randrange(38, W - 38), -22,
                                 random.randrange(11, 23), 2 + difficulty * 0.23])
        for shot in self.shots[:]:
            shot[1] -= 18
            if shot[1] < -20:
                self.shots.remove(shot)
        for m in self.meteors[:]:
            m[1] += m[3]
            if m[1] > H - 60:
                self.health -= 1
                self.sparkles.extend((m[0], m[1], random.randrange(-7, 7), random.randrange(-7, 7), 12)
                                     for _ in range(8))
                self.meteors.remove(m)
                if self.health <= 0:
                    self.dead = True
                continue
            for shot in self.shots[:]:
                if abs(shot[0] - m[0]) < m[2] + 6 and abs(shot[1] - m[1]) < m[2] + 12:
                    self.score += 10
                    self.sparkles.extend((m[0], m[1], random.randrange(-9, 9), random.randrange(-9, 9), 14)
                                         for _ in range(9))
                    self.meteors.remove(m)
                    self.shots.remove(shot)
                    break
        self.sparkles = [(x+vx, y+vy, vx, vy, time-1) for x, y, vx, vy, time in self.sparkles if time > 0]

    def draw(self):
        c = self.canvas
        c.delete('frame')
        for x, y, size in self.stars:
            sy = (y + self.tick * 0.17 * size) % H
            c.create_oval(x, sy, x+size, sy+size, fill='#344568', outline='', tags='frame')
        c.create_rectangle(0, H-62, W, H, fill='#0b1d36', outline='', tags='frame')
        for x in range(0, W, 53):
            c.create_line(x, H-62, x+20, H, fill='#1a4d72', tags='frame')
        c.create_line(0, H-62, W, H-62, fill='#4acddf', width=2, tags='frame')
        c.create_oval(W/2-130, 8, W/2+130, 270, outline='#142c4b', width=1, tags='frame')
        c.create_oval(W/2-90, 48, W/2+90, 230, outline='#122d49', width=2, tags='frame')
        for x, y, radius, speed in self.meteors:
            c.create_oval(x-radius-5, y-radius-5, x+radius+5, y+radius+5,
                          outline='#743256', width=2, tags='frame')
            c.create_oval(x-radius, y-radius, x+radius, y+radius,
                          outline=PINK, width=3, tags='frame')
            c.create_line(x, y-radius-18, x, y+radius, fill='#b24180', width=2, tags='frame')
        for x, y in self.shots:
            c.create_line(x, y+19, x, y-15, fill=CYAN, width=4, tags='frame')
        for x, y, vx, vy, ttl in self.sparkles:
            c.create_rectangle(x, y, x+4, y+4, fill='#ffba6d', outline='', tags='frame')
        px = self.player
        c.create_polygon(px, H-100, px+32, H-60, px+11, H-65, px-11, H-65, px-32, H-60,
                         outline=CYAN, fill='#103a53', width=3, tags='frame')
        c.create_line(px, H-88, px, H-58, fill='#c1faff', width=2, tags='frame')
        c.create_text(22, 22, text='ORBIT DEFENDER', fill=CYAN,
                      anchor='nw', font=('DejaVu Sans', 24, 'bold'), tags='frame')
        c.create_text(24, 66, text='SCORE %04d     SHIELDS %s' % (self.score, '◆' * self.health),
                      fill='#d6e9ff', anchor='nw', font=('DejaVu Sans', 15), tags='frame')
        c.create_text(W - 18, H-25,
                      text='← → move  •  SPACE shoot  •  TAP aim + shoot  •  P pause  •  R retry',
                      fill='#92aac4', anchor='e', font=('DejaVu Sans', 13), tags='frame')
        if self.dead or self.paused:
            c.create_rectangle(155, 155, W-155, 330, fill='#091222', outline='#4b84af', width=3, tags='frame')
            c.create_text(W/2, 215, text='DEFENSE LOST' if self.dead else 'PAUSED', fill=PINK,
                          font=('DejaVu Sans', 35, 'bold'), tags='frame')
            c.create_text(W/2, 280, text='R or tap to restart' if self.dead else 'P to continue',
                          fill='#d8e6fb', font=('DejaVu Sans', 17), tags='frame')

    def frame(self):
        try:
            self.update()
            self.draw()
            self.root.after(50, self.frame)
        except tk.TclError:
            pass


if __name__ == '__main__':
    Game()
