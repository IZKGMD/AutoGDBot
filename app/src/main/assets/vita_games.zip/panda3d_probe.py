#!/usr/bin/env python3
"""Panda3D 3D proof of concept. Experimental on ARMv7/PS Vita; desktop reference."""
from direct.showbase.ShowBase import ShowBase
from direct.task import Task
from panda3d.core import CardMaker, Vec4, WindowProperties
import math


class Probe(ShowBase):
    def __init__(self):
        super().__init__()
        props = WindowProperties()
        props.setTitle('Vita 3D Probe | Panda3D')
        props.setSize(800, 480)
        self.win.requestProperties(props)
        self.setBackgroundColor(.02, .04, .10)
        self.disableMouse()
        self.camera.setPos(0, -15, 4)
        self.camera.lookAt(0, 0, 0)
        self.parts = []
        for i in range(12):
            card = CardMaker('tower_%d' % i)
            card.setFrame(-.6, .6, -.6, .6)
            node = self.render.attachNewNode(card.generate())
            node.setTwoSided(True)
            node.setPos((i % 6 - 2.5) * 1.5, i // 6 * 2.5, 0)
            node.setColor(Vec4(.3 + i * .04, .8, 1, 1))
            self.parts.append(node)
        self.accept('escape', self.userExit)
        self.taskMgr.add(self.animate, 'animation')

    def animate(self, task):
        for i, node in enumerate(self.parts):
            node.setHpr(task.time * 27 + i * 20, 0, 12 * math.sin(task.time + i))
            node.setZ(math.sin(task.time * 2 + i * .6))
        return Task.cont


if __name__ == '__main__':
    Probe().run()
